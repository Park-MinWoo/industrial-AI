import cv2
import numpy as np

images = []
images.append(cv2.imread('/Users/park/PycharmProjects/photo/stitching/boat1.jpg', cv2.IMREAD_COLOR))
images.append(cv2.imread('/Users/park/PycharmProjects/photo/stitching/boat2.jpg', cv2.IMREAD_COLOR))
images.append(cv2.imread('/Users/park/PycharmProjects/photo/stitching/boat3.jpg', cv2.IMREAD_COLOR))
images.append(cv2.imread('/Users/park/PycharmProjects/photo/stitching/boat4.jpg', cv2.IMREAD_COLOR))
images.append(cv2.imread('/Users/park/PycharmProjects/photo/stitching/boat5.jpg', cv2.IMREAD_COLOR))
images.append(cv2.imread('/Users/park/PycharmProjects/photo/stitching/boat6.jpg', cv2.IMREAD_COLOR))

stitcher = cv2.createStitcher()
ret, pano = stitcher.stitch(images)

if ret == cv2.STITCHER_OK:
    pano = cv2.resize(pano, dsize=(0, 0), fx=0.5, fy=0.5)
    cv2.imshow('boat panorama', pano)
    cv2.waitKey()
    cv2.destroyAllWindows()

else:
    print('Error during stiching')