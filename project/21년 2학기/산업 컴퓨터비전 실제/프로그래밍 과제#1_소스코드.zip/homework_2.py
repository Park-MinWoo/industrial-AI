import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread("/Users/park/PycharmProjects/TestImage/Lena.png").astype(np.float32) / 255

noised = (img + 0.2 * np.random.rand(*img.shape).astype(np.float32))
noised = noised.clip(0, 1)

d = np.int(input("Diameter:"))
# sc, ss = np.double(input("Sigma Color:, Sigma Space:").split())
sc = np.int(input("Sigma Color:"))
ss = np.int(input("Sigma Space:"))

bilat = cv2.bilateralFilter(noised, d, sc, ss)

cv2.imshow("noised", noised)
cv2.imshow("bilateralFilter", bilat)
cv2.waitKey()
cv2.destroyAllWindows()