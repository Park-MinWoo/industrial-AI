import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread("/Users/park/PycharmProjects/TestImage/Lena.png", cv2.IMREAD_COLOR)
kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))

def imageDilation(image, kernel, iterations = 1):
    return cv2.dilate(image, kernel=kernel, iterations=iterations)

def imageErosion(image, kernel, iterations = 1):
    return cv2.erode(image, kernel=kernel, iterations=iterations)

def imageOpening(image, iterations = 1):
    kernel = np.ones((3, 3), np.uint8)
    erosion = imageErosion(image, kernel, iterations)
    return imageDilation(erosion, kernel, iterations)

def imageClosing(image, iterations = 1):
    kernel = np.ones((3, 3), np.uint8)
    dilation = imageDilation(image, kernel, iterations)
    return imageErosion(dilation, kernel, iterations)

choise = input("E(Erosion), D(Dilation), O(Opening), C(Closing):").upper()
choiseNo = np.int(input("횟수를 입력하시오: "))

imgCopy = img.copy()

for i in range(choiseNo):
    if choise == "E":
        imgCopy = imageDilation(imgCopy, kernel)
    elif choise == "D":
        imgCopy = imageErosion(imgCopy, kernel)
    elif choise == "O":
        imgCopy = imageOpening(imgCopy)
    elif choise == "C":
        imgCopy = imageClosing(imgCopy)

cv2.imshow("result", imgCopy)
cv2.waitKey()
cv2.destroyAllWindows()