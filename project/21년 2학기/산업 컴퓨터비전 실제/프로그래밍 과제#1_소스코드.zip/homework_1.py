import cv2
import numpy as np
import matplotlib.pyplot as plt

img = cv2.imread("/Users/park/PycharmProjects/TestImage/Lena.png", cv2.IMREAD_COLOR)

imgEq = img.copy()
b, g, r = cv2.split(img)
inColor = input("r/g/b 중 입력하시오")
eq = cv2.equalizeHist(b)

if inColor == "b":    
    imgEq = cv2.merge((eq, g, r))
elif inColor == "g":
    eq = cv2.equalizeHist(g)
    imgEq = cv2.merge((r, eq, r))
elif inColor == "r":
    eq = cv2.equalizeHist(r)
    imgEq = cv2.merge((b, g, eq))

hist, bins = np.histogram(eq, 256, [0, 255])
plt.fill(hist)
plt.xlabel('histogram')
plt.show()

cv2.imshow("orginal image", img)
cv2.imshow("equalize color=" + inColor, imgEq)
cv2.waitKey()
cv2.destroyAllWindows()